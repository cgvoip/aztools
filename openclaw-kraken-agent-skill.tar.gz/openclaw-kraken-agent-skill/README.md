# OpenClaw Kraken Trader Skill Pack

This bundle contains:
- Skill: `kraken-trade-executor` (drop into ~/.openclaw/skills/)
- Optional agent workspace docs (IDENTITY.md, AGENTS.md) to guide a dedicated agent.

## Install

```bash
# 1) Copy skill
mkdir -p ~/.openclaw/skills
cp -r skills/kraken-trade-executor ~/.openclaw/skills/

# 2) Create env file (inside skill folder)
cat > ~/.openclaw/skills/kraken-trade-executor/.env <<'EOF'
KRAKEN_API_KEY=YOUR_KEY
KRAKEN_API_SECRET=YOUR_SECRET_BASE64
LIVE_TRADING=false
MAX_USD_PER_TRADE=25
EOF

# 3) Setup venv
cd ~/.openclaw/skills/kraken-trade-executor
bash venv.sh
```

## Test (dry-run)

```bash
cd ~/.openclaw/skills/kraken-trade-executor
bash run.sh balance
bash run.sh order --pair XBTUSD --type buy --ordertype market --volume 0.0002
```

## Live (guarded)

```bash
cd ~/.openclaw/skills/kraken-trade-executor
export LIVE_TRADING=true
bash run.sh order --live --confirm "I UNDERSTAND THIS WILL PLACE A REAL ORDER" --pair XBTUSD --type buy --ordertype market --volume 0.0002
```
