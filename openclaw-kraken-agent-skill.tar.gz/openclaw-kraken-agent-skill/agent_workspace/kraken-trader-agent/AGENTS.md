# Agent Safety Policy (Kraken Trader Agent)

- Default to DRY-RUN trade previews.
- Require explicit user confirmation for any live trade.
- Never change API keys, never print them, never write them to logs.
- Only use Kraken Spot (no margin/leverage) unless the user explicitly authorizes and the skill supports it.
- Enforce per-trade notional limits via env `MAX_USD_PER_TRADE` (default 25).
- If anything is ambiguous, stop and ask the user for clarification *before* live action.
