#!/usr/bin/env python3
"""
OpenClaw-safe Kraken Spot executor.
- Prints EXACTLY ONE JSON object to stdout
- Dry-run by default
"""
import argparse
import base64
import hashlib
import hmac
import json
import os
import time
import urllib.parse
from typing import Any, Dict, Optional

import requests

API_URL = "https://api.kraken.com"
API_VERSION = "0"

def _env(name: str, default: Optional[str]=None) -> Optional[str]:
    v = os.environ.get(name)
    return v if v not in (None, "") else default

def _bool_env(name: str, default: bool=False) -> bool:
    v = _env(name)
    if v is None:
        return default
    return v.strip().lower() in ("1","true","yes","y","on")

def _mask(s: str, keep: int=4) -> str:
    if not s:
        return ""
    if len(s) <= keep:
        return "*" * len(s)
    return s[:keep] + "*" * (len(s)-keep)

def kraken_sign(urlpath: str, data: Dict[str, str], secret_b64: str) -> str:
    """
    Kraken Spot REST auth signature.
    Docs: https://docs.kraken.com/api/docs/guides/spot-rest-auth/
    """
    postdata = urllib.parse.urlencode(data)
    encoded = (str(data["nonce"]) + postdata).encode()
    message = urlpath.encode() + hashlib.sha256(encoded).digest()
    mac = hmac.new(base64.b64decode(secret_b64), message, hashlib.sha512)
    return base64.b64encode(mac.digest()).decode()

def kraken_private(method: str, data: Dict[str, str], api_key: str, api_secret_b64: str, timeout: int=30) -> Any:
    urlpath = f"/{API_VERSION}/private/{method}"
    url = API_URL + urlpath

    # Kraken requires a nonce that always increases
    data = dict(data)
    data["nonce"] = str(int(time.time() * 1000))

    headers = {
        "API-Key": api_key,
        "API-Sign": kraken_sign(urlpath, data, api_secret_b64),
        "User-Agent": "openclaw-kraken-trade-executor/0.1.0",
    }
    resp = requests.post(url, data=data, headers=headers, timeout=timeout)
    try:
        payload = resp.json()
    except Exception:
        raise RuntimeError(f"Non-JSON response (HTTP {resp.status_code}): {resp.text[:400]}")
    if resp.status_code != 200:
        raise RuntimeError(f"HTTP {resp.status_code}: {payload}")
    if payload.get("error"):
        raise RuntimeError(f"Kraken API error: {payload.get('error')}")
    return payload.get("result")

def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("balance")
    sub.add_parser("open-orders")

    p_order = sub.add_parser("order")
    p_order.add_argument("--pair", required=True, help="Kraken pair, e.g. XBTUSD or XBTUSDT (depends on your account/market)")
    p_order.add_argument("--type", required=True, choices=["buy","sell"])
    p_order.add_argument("--ordertype", default="market", help="market|limit|stop-loss|take-profit|...")
    p_order.add_argument("--price", help="Required for limit orders")
    p_order.add_argument("--volume", required=True, help="Order volume in base units")
    p_order.add_argument("--live", action="store_true", help="Actually place the order (requires LIVE_TRADING=true and --confirm)")
    p_order.add_argument("--confirm", default="", help="Must equal: I UNDERSTAND THIS WILL PLACE A REAL ORDER")

    p_cancel = sub.add_parser("cancel")
    p_cancel.add_argument("--txid", required=True)
    p_cancel.add_argument("--live", action="store_true")
    p_cancel.add_argument("--confirm", default="")

    args = ap.parse_args()

    api_key = _env("KRAKEN_API_KEY")
    api_secret = _env("KRAKEN_API_SECRET")

    out: Dict[str, Any] = {"ok": False, "cmd": args.cmd}

    if not api_key or not api_secret:
        out["error"] = "Missing Kraken credentials. Set KRAKEN_API_KEY and KRAKEN_API_SECRET."
        print(json.dumps(out))
        return 2

    # Safety guardrails
    live_trading_env = _bool_env("LIVE_TRADING", False)
    max_usd = float(_env("MAX_USD_PER_TRADE", "25") or "25")
    required_confirm = "I UNDERSTAND THIS WILL PLACE A REAL ORDER"

    try:
        if args.cmd == "balance":
            result = kraken_private("Balance", {}, api_key, api_secret)
            out.update({"ok": True, "result": result})
            print(json.dumps(out, ensure_ascii=False))
            return 0

        if args.cmd == "open-orders":
            result = kraken_private("OpenOrders", {"trades": "false"}, api_key, api_secret)
            out.update({"ok": True, "result": result})
            print(json.dumps(out, ensure_ascii=False))
            return 0

        if args.cmd == "order":
            # Always return a dry-run preview unless explicitly live
            is_live = bool(args.live) and live_trading_env and (args.confirm.strip() == required_confirm)

            data: Dict[str, str] = {
                "pair": args.pair,
                "type": args.type,
                "ordertype": args.ordertype,
                "volume": str(args.volume),
            }
            if args.price:
                data["price"] = str(args.price)

            # Optional risk check: if the user is placing a market buy/sell without price,
            # we can't compute notional reliably. We keep a conservative guard: require explicit confirm for live.
            out["dry_run"] = not is_live
            out["requested_order"] = {k: v for k, v in data.items()}

            if not is_live:
                out["ok"] = True
                out["note"] = "DRY-RUN. To place a real order: set LIVE_TRADING=true, add --live and the exact --confirm string."
                print(json.dumps(out, ensure_ascii=False))
                return 0

            # Live: place order
            result = kraken_private("AddOrder", data, api_key, api_secret)
            out.update({"ok": True, "dry_run": False, "result": result})
            print(json.dumps(out, ensure_ascii=False))
            return 0

        if args.cmd == "cancel":
            is_live = bool(args.live) and live_trading_env and (args.confirm.strip() == required_confirm)
            out["dry_run"] = not is_live
            out["txid"] = args.txid
            if not is_live:
                out["ok"] = True
                out["note"] = "DRY-RUN. To cancel for real: set LIVE_TRADING=true, add --live and the exact --confirm string."
                print(json.dumps(out, ensure_ascii=False))
                return 0

            result = kraken_private("CancelOrder", {"txid": args.txid}, api_key, api_secret)
            out.update({"ok": True, "dry_run": False, "result": result})
            print(json.dumps(out, ensure_ascii=False))
            return 0

        out["error"] = "Unknown command"
        print(json.dumps(out))
        return 2

    except Exception as e:
        out["error"] = str(e)
        # never print secrets
        out["diag"] = {"api_key": _mask(api_key), "live_trading_env": live_trading_env, "max_usd_per_trade": max_usd}
        print(json.dumps(out, ensure_ascii=False))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
