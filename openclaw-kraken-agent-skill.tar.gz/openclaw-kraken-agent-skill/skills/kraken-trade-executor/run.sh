#!/usr/bin/env bash
set -euo pipefail

# Run from skill root even if invoked elsewhere
SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Load .env if present
if [ -f "$SKILL_DIR/.env" ]; then
  set -a
  # shellcheck disable=SC1090
  source "$SKILL_DIR/.env"
  set +a
fi

PY="$SKILL_DIR/.venv/bin/python"
if [ ! -x "$PY" ]; then
  PY="$(command -v python3)"
fi

exec "$PY" "$SKILL_DIR/scripts/kraken_exec.py" "$@"
