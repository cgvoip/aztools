---
name: kraken-trade-executor
description: Execute Kraken Spot trades safely (dry-run by default). Can place orders only when LIVE_TRADING=true and --live is provided.
version: 0.1.0
requires:
  bins:
    - python3
  env:
    - KRAKEN_API_KEY
    - KRAKEN_API_SECRET
optional:
  env:
    - TAAPI_TOKEN
    - TAAPI_SECRET
os:
  - linux
  - darwin
---

# Kraken Trade Executor (OpenClaw Skill)

This skill provides a **safe-by-default** interface for creating Kraken Spot orders and checking balances.

## Safety rules (do not violate)

- **Default mode is DRY-RUN**: it must not place real orders unless:
  1) `LIVE_TRADING=true` is present in the environment, **and**
  2) the user explicitly passes `--live`, **and**
  3) the user provides all required order parameters.
- Never log or print secrets (`KRAKEN_API_SECRET`, `TAAPI_TOKEN`, etc.). If diagnostics are enabled, mask secrets.
- Enforce risk guardrails:
  - Max USD notional per order default: `$25` (configurable by `MAX_USD_PER_TRADE`)
  - Reject leverage/margin by default (spot only)
  - Require an explicit `--confirm` string for live orders.

## Files

- `scripts/kraken_exec.py` — main executable (JSON in/out)
- `run.sh` — loads `.env` (if present) and runs the python script using the local `.venv` if available
- `venv.sh` — creates `.venv` and installs dependencies

## Quick start

1) In the skill folder, create `.env`:

```bash
KRAKEN_API_KEY=your_key
KRAKEN_API_SECRET=your_secret_base64
LIVE_TRADING=false
MAX_USD_PER_TRADE=25
```

2) Create venv + install deps:

```bash
bash venv.sh
```

3) Dry-run example (recommended):

```bash
bash run.sh balance
bash run.sh order --pair XBTUSD --type buy --ordertype market --volume 0.0002
```

4) Live order (requires explicit opt-in):

```bash
export LIVE_TRADING=true
bash run.sh order --live --confirm "I UNDERSTAND THIS WILL PLACE A REAL ORDER" --pair XBTUSD --type buy --ordertype market --volume 0.0002
```

## Commands (via `run.sh`)

- `balance` — returns account balance snapshot
- `order` — creates an order (dry-run unless live)
- `open-orders` — list open orders
- `cancel` — cancel an order by txid (live-only, guarded)

All commands print **exactly one JSON object** to stdout (OpenClaw-safe).
